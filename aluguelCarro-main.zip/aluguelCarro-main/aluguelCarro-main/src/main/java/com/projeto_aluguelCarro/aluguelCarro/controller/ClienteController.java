package com.projeto_aluguelCarro.aluguelCarro.controller;

import com.projeto_aluguelCarro.aluguelCarro.dto.ClienteDTO;
import com.projeto_aluguelCarro.aluguelCarro.service.ClienteService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * Controller REST para operações de gerenciamento dos clientes da locadora.
 *
 * Responsabilidades: receber requisições HTTP, delegar ao ClienteService,
 * retornar respostas JSON com status HTTP adequados.
 *
 * Endpoints expostos:
 *   GET    /clientes       → listar todos
 *   GET    /clientes/{id}  → buscar por ID
 *   POST   /clientes       → cadastrar
 *   PUT    /clientes/{id}  → atualizar (CPF não é alterado — regra do Service)
 *   DELETE /clientes/{id}  → remover (falha se tiver aluguéis — regra do Service)
 */
@RestController
@RequestMapping("/clientes")
public class ClienteController {

    private final ClienteService clienteService;

    // Injeção via construtor
    public ClienteController(ClienteService clienteService) {
        this.clienteService = clienteService;
    }

    /**
     * GET /clientes
     * Retorna lista com todos os clientes cadastrados (RF09).
     */
    @GetMapping
    public List<ClienteDTO> listarTodos() {
        return clienteService.listarTodos();
    }

    /**
     * GET /clientes/{id}
     * Busca um cliente pelo ID (RF09).
     */
    @GetMapping("/{id}")
    public ClienteDTO buscarPorId(@PathVariable Long id) {
        return clienteService.buscarPorId(id);
    }

    /**
     * POST /clientes
     * Cadastra um novo cliente (RF07).
     * O Service valida CPF único (RF08) antes de persistir.
     */
    @PostMapping
    public ClienteDTO salvar(@RequestBody ClienteDTO dto) {
        return clienteService.salvar(dto);
    }

    /**
     * PUT /clientes/{id}
     * Atualiza os dados de um cliente (RF10).
     * O CPF enviado no body é ignorado pelo Service — não pode ser alterado.
     */
    @PutMapping("/{id}")
    public ClienteDTO atualizar(@PathVariable Long id, @RequestBody ClienteDTO dto) {
        return clienteService.atualizar(id, dto);
    }

    /**
     * DELETE /clientes/{id}
     * Remove um cliente (RF11).
     * O Service lança exceção se o cliente possuir aluguéis registrados.
     * Retorna HTTP 204 No Content em caso de sucesso.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        clienteService.deletar(id);
        return ResponseEntity.noContent().build(); // HTTP 204 No Content
    }
}

package com.projeto_aluguelCarro.aluguelCarro.repository;

import com.projeto_aluguelCarro.aluguelCarro.domain.Aluguel;
import com.projeto_aluguelCarro.aluguelCarro.domain.enums.StatusAluguel;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;

/**
 * Repositório JPA para a entidade Aluguel.
 *
 * Herda operações CRUD completas de JpaRepository<Aluguel, Long>.
 * Os métodos abaixo são derived queries geradas automaticamente pelo Spring Data JPA —
 * o framework lê o nome do método e gera o SQL correspondente sem precisar de @Query.
 *
 * Padrão de Projeto: Repository (DAO) — abstrai o acesso ao banco.
 */
public interface AluguelRepository extends JpaRepository<Aluguel, Long> {

    /**
     * Lista todos os aluguéis de um determinado cliente.
     * SQL gerado: SELECT * FROM alugueis WHERE cliente_id = ?
     * Usado em: GET /alugueis/cliente/{clienteId} (RF19)
     */
    List<Aluguel> findByClienteId(Long clienteId);

    /**
     * Lista aluguéis por status (ATIVO, CONCLUIDO, CANCELADO, PENDENTE).
     * SQL gerado: SELECT * FROM alugueis WHERE status = ?
     * Não exposto via endpoint nesta versão, mas disponível para uso interno.
     */
    List<Aluguel> findByStatus(StatusAluguel status);

    /**
     * Lista aluguéis cuja dataInicio está dentro do intervalo informado.
     * SQL gerado: SELECT * FROM alugueis WHERE data_inicio BETWEEN ? AND ?
     * Usado em: GET /alugueis/periodo?inicio=...&fim=... (RF19)
     */
    List<Aluguel> findByDataInicioBetween(LocalDate inicio, LocalDate fim);

    /**
     * Verifica se existe algum aluguel vinculado ao cliente informado.
     * SQL gerado: SELECT COUNT(*) > 0 FROM alugueis WHERE cliente_id = ?
     * Usado no ClienteService para bloquear exclusão de clientes com aluguéis (RF11).
     */
    boolean existsByClienteId(Long clienteId);
}

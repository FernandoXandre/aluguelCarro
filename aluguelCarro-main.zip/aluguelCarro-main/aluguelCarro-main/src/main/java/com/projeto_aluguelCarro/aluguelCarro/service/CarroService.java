package com.projeto_aluguelCarro.aluguelCarro.service;

import com.projeto_aluguelCarro.aluguelCarro.domain.Carro;
import com.projeto_aluguelCarro.aluguelCarro.dto.CarroDTO;
import com.projeto_aluguelCarro.aluguelCarro.repository.CarroRepository;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Serviço responsável pela lógica de negócio dos veículos da frota.
 *
 * Camada de serviço (Service Layer Pattern):
 *   - Recebe dados do Controller (via DTO)
 *   - Aplica validações e regras de negócio
 *   - Delega persistência ao Repository
 *   - Retorna DTO ao Controller
 *
 * A dependência (CarroRepository) é injetada via construtor — prática recomendada
 * pelo Spring (Dependency Injection / IoC), pois facilita testes unitários com mocks
 * e torna as dependências explícitas.
 *
 * @Service indica ao Spring que esta classe deve ser gerenciada como um bean
 * e estará disponível para injeção em outras classes (ex: CarroController).
 */
@Service
public class CarroService {

    private final CarroRepository carroRepository;

    // Injeção via construtor: o Spring fornece automaticamente uma instância de CarroRepository
    public CarroService(CarroRepository carroRepository) {
        this.carroRepository = carroRepository;
    }

    /**
     * Retorna todos os carros cadastrados na frota.
     * Converte cada entidade Carro em CarroDTO antes de retornar (RF03).
     */
    public List<CarroDTO> listarTodos() {
        return carroRepository.findAll().stream()
                .map(this::toDTO)  // this::toDTO é uma referência ao método privado abaixo
                .toList();
    }

    /**
     * Retorna apenas os carros com o campo disponivel = true.
     * Usado para mostrar ao atendente quais carros podem ser alugados (RF04).
     */
    public List<CarroDTO> listarDisponiveis() {
        return carroRepository.findByDisponivelTrue().stream()
                .map(this::toDTO)
                .toList();
    }

    /**
     * Busca um carro pelo ID. Lança RuntimeException se não encontrado.
     * O orElseThrow transforma o Optional vazio em uma exceção com mensagem clara.
     */
    public CarroDTO buscarPorId(Long id) {
        return toDTO(carroRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Carro não encontrado: " + id)));
    }

    /**
     * Cadastra um novo veículo na frota.
     * Regra de negócio RF02: impede placa duplicada antes de persistir.
     */
    public CarroDTO salvar(CarroDTO dto) {
        // Verifica se já existe outro carro com a mesma placa
        if (carroRepository.existsByPlaca(dto.placa())) {
            throw new RuntimeException("Já existe um carro com a placa: " + dto.placa());
        }
        // Converte DTO em entidade e salva no banco
        return toDTO(carroRepository.save(toEntity(dto)));
    }

    /**
     * Atualiza os dados de um veículo existente.
     * Regra de negócio RF05: a placa NÃO é atualizada para evitar
     * inconsistências com aluguéis que já referenciam o veículo.
     */
    public CarroDTO atualizar(Long id, CarroDTO dto) {
        // Busca o carro existente no banco (falha se não existir)
        Carro carro = carroRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Carro não encontrado: " + id));

        // Atualiza apenas os campos permitidos — placa é preservada intencionalmente
        carro.setMarca(dto.marca());
        carro.setModelo(dto.modelo());
        carro.setAno(dto.ano());
        carro.setValorDiaria(dto.valorDiaria());
        carro.setCategoria(dto.categoria());
        carro.setDisponivel(dto.disponivel());

        return toDTO(carroRepository.save(carro));
    }

    /**
     * Remove um veículo da frota pelo ID (RF06).
     * Nota: esta versão não verifica aluguéis ativos — uma melhoria futura
     * poderia bloquear a exclusão se o carro tiver aluguéis vinculados.
     */
    public void deletar(Long id) {
        carroRepository.deleteById(id);
    }

    // -----------------------------------------------------------------------
    // Métodos privados de conversão (evitam repetição de código)
    // -----------------------------------------------------------------------

    /**
     * Converte entidade Carro em CarroDTO para resposta da API.
     * Garante que apenas os dados necessários sejam expostos.
     */
    private CarroDTO toDTO(Carro c) {
        return new CarroDTO(c.getId(), c.getMarca(), c.getModelo(), c.getPlaca(),
                c.getAno(), c.getValorDiaria(), c.getDisponivel(), c.getCategoria());
    }

    /**
     * Converte CarroDTO recebido da requisição em entidade Carro para persistência.
     * Se o campo disponivel vier null no JSON, assume true (disponível por padrão).
     */
    private Carro toEntity(CarroDTO dto) {
        return Carro.builder()
                .id(dto.id())
                .marca(dto.marca())
                .modelo(dto.modelo())
                .placa(dto.placa())
                .ano(dto.ano())
                .valorDiaria(dto.valorDiaria())
                // Garante disponivel = true quando o campo vier null no request (novo carro)
                .disponivel(dto.disponivel() != null ? dto.disponivel() : true)
                .categoria(dto.categoria())
                .build();
    }
}

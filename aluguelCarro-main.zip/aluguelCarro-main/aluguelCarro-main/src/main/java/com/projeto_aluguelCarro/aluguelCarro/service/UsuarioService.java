package com.projeto_aluguelCarro.aluguelCarro.service;

import com.projeto_aluguelCarro.aluguelCarro.domain.Usuario;
import com.projeto_aluguelCarro.aluguelCarro.dto.UsuarioDTO;
import com.projeto_aluguelCarro.aluguelCarro.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Serviço responsável pela lógica de negócio dos usuários operacionais do sistema.
 *
 * Design de segurança (RF22 / RNF05):
 *   A senha é recebida fora do UsuarioDTO (como parâmetro separado no método salvar)
 *   para garantir que ela NUNCA seja retornada nas respostas JSON da API.
 *   O UsuarioDTO utilizado como retorno não contém o campo senha.
 *
 *   Melhoria futura prevista (RNF05): aplicar hash com BCrypt via Spring Security
 *   antes de salvar a senha no banco.
 */
@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    // Injeção via construtor
    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    /**
     * Retorna todos os usuários cadastrados (RF20).
     * A senha é omitida automaticamente pois o UsuarioDTO não a inclui.
     */
    public List<UsuarioDTO> listarTodos() {
        return usuarioRepository.findAll().stream()
                .map(this::toDTO)
                .toList();
    }

    /**
     * Busca um usuário pelo ID.
     * Lança RuntimeException com mensagem clara se não encontrado.
     */
    public UsuarioDTO buscarPorId(Long id) {
        return toDTO(usuarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado: " + id)));
    }

    /**
     * Cadastra um novo usuário (RF20).
     * Regra RF21: impede username duplicado antes de persistir.
     *
     * @param dto   dados públicos do usuário (sem senha)
     * @param senha recebida separadamente para nunca compor o DTO de resposta
     */
    public UsuarioDTO salvar(UsuarioDTO dto, String senha) {
        // Verifica unicidade do username antes de salvar
        if (usuarioRepository.existsByUsername(dto.username())) {
            throw new RuntimeException("Username já cadastrado: " + dto.username());
        }
        Usuario usuario = Usuario.builder()
                .username(dto.username())
                .senha(senha)       // Armazenada em texto puro nesta versão
                .perfil(dto.perfil())
                .build();
        return toDTO(usuarioRepository.save(usuario));
    }

    /**
     * Remove um usuário pelo ID.
     * Nota: aluguéis vinculados ao usuário terão usuario_id = NULL após a exclusão
     * (ON DELETE SET NULL definido no script SQL — preserva o histórico de aluguéis).
     */
    public void deletar(Long id) {
        usuarioRepository.deleteById(id);
    }

    // -----------------------------------------------------------------------
    // Método privado de conversão
    // -----------------------------------------------------------------------

    /**
     * Converte entidade Usuario em UsuarioDTO.
     * A senha é omitida intencionalmente — não compõe o UsuarioDTO (RF22).
     */
    private UsuarioDTO toDTO(Usuario u) {
        return new UsuarioDTO(u.getId(), u.getUsername(), u.getPerfil());
    }
}

package com.projeto_aluguelCarro.aluguelCarro.repository;

import com.projeto_aluguelCarro.aluguelCarro.domain.Carro;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

/**
 * Repositório JPA para a entidade Carro.
 *
 * Ao estender JpaRepository<Carro, Long>, esta interface herda gratuitamente:
 *   - findAll()          → SELECT * FROM carros
 *   - findById(id)       → SELECT * FROM carros WHERE id = ?
 *   - save(carro)        → INSERT ou UPDATE
 *   - deleteById(id)     → DELETE FROM carros WHERE id = ?
 *   - existsById(id)     → SELECT COUNT(*) > 0 WHERE id = ?
 *   - entre outros
 *
 * Os métodos abaixo são "derived queries": o Spring Data JPA gera o SQL
 * automaticamente a partir do nome do método. Nenhum SQL manual é necessário.
 *
 * Padrão de Projeto: Repository (DAO) — abstrai o acesso ao banco.
 */
public interface CarroRepository extends JpaRepository<Carro, Long> {

    /**
     * Retorna todos os carros com disponivel = true.
     * SQL gerado: SELECT * FROM carros WHERE disponivel = 1
     * Usado em: GET /carros/disponiveis (RF04)
     */
    List<Carro> findByDisponivelTrue();

    /**
     * Busca um carro pela placa.
     * SQL gerado: SELECT * FROM carros WHERE placa = ?
     * Retorna Optional para forçar tratamento do caso "não encontrado".
     */
    Optional<Carro> findByPlaca(String placa);

    /**
     * Verifica se já existe um carro com a placa informada.
     * SQL gerado: SELECT COUNT(*) > 0 FROM carros WHERE placa = ?
     * Usado no CarroService para impedir placa duplicada (RF02).
     */
    boolean existsByPlaca(String placa);
}

package com.projeto_aluguelCarro.aluguelCarro.service;

import com.projeto_aluguelCarro.aluguelCarro.domain.*;
import com.projeto_aluguelCarro.aluguelCarro.domain.enums.StatusAluguel;
import com.projeto_aluguelCarro.aluguelCarro.dto.AluguelDTO;
import com.projeto_aluguelCarro.aluguelCarro.repository.*;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * Serviço responsável por toda a lógica de negócio dos aluguéis.
 *
 * É o serviço mais complexo da aplicação — orquestra quatro repositórios,
 * calcula valores monetários e controla o ciclo de vida dos aluguéis e
 * a disponibilidade dos veículos.
 *
 * Ciclo de vida gerenciado aqui:
 *   criar()    → status = ATIVO,     carro.disponivel = false
 *   concluir() → status = CONCLUIDO, carro.disponivel = true
 *   cancelar() → status = CANCELADO, carro.disponivel = true
 *
 * Injeção via construtor de 4 repositórios: boa prática do Spring,
 * favorece testes unitários (cada repositório pode ser mockado individualmente).
 */
@Service
public class AluguelService {

    private final AluguelRepository aluguelRepository;
    private final CarroRepository   carroRepository;
    private final ClienteRepository clienteRepository;
    private final UsuarioRepository usuarioRepository;

    public AluguelService(AluguelRepository aluguelRepository,
                          CarroRepository carroRepository,
                          ClienteRepository clienteRepository,
                          UsuarioRepository usuarioRepository) {
        this.aluguelRepository = aluguelRepository;
        this.carroRepository   = carroRepository;
        this.clienteRepository = clienteRepository;
        this.usuarioRepository = usuarioRepository;
    }

    /**
     * Retorna todos os aluguéis cadastrados.
     */
    public List<AluguelDTO> listarTodos() {
        return aluguelRepository.findAll().stream()
                .map(this::toDTO)
                .toList();
    }

    /**
     * Busca um aluguel pelo ID.
     * Lança RuntimeException com mensagem clara se não encontrado.
     */
    public AluguelDTO buscarPorId(Long id) {
        return toDTO(aluguelRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Aluguel não encontrado: " + id)));
    }

    /**
     * Lista todos os aluguéis de um cliente específico (RF19).
     * Delega a query ao AluguelRepository.findByClienteId().
     */
    public List<AluguelDTO> listarPorCliente(Long clienteId) {
        return aluguelRepository.findByClienteId(clienteId).stream()
                .map(this::toDTO)
                .toList();
    }

    /**
     * Lista aluguéis cujo dataInicio está dentro do intervalo fornecido (RF19).
     * Exemplo de uso: GET /alugueis/periodo?inicio=2026-01-01&fim=2026-12-31
     */
    public List<AluguelDTO> listarPorPeriodo(LocalDate inicio, LocalDate fim) {
        return aluguelRepository.findByDataInicioBetween(inicio, fim).stream()
                .map(this::toDTO)
                .toList();
    }

    /**
     * Cria um novo aluguel aplicando todas as regras de negócio (RF12 a RF16).
     *
     * Regras aplicadas neste método:
     *   RF12 → vincula cliente, carro e usuário
     *   RF13 → calcula valorTotal = dias × valorDiaria do carro
     *   RF14 → impede aluguel de carro indisponível
     *   RF15 → impede datas inválidas (dataFim <= dataInicio)
     *   RF16 → marca o carro como indisponível após criar o aluguel
     */
    public AluguelDTO criar(AluguelDTO dto) {

        // --- RF14: verifica se o carro existe e está disponível ---
        Carro carro = carroRepository.findById(dto.carroId())
                .orElseThrow(() -> new RuntimeException("Carro não encontrado: " + dto.carroId()));

        if (!carro.getDisponivel()) {
            throw new RuntimeException("Carro não está disponível para aluguel.");
        }

        // --- Busca o cliente (obrigatório) ---
        Cliente cliente = clienteRepository.findById(dto.clienteId())
                .orElseThrow(() -> new RuntimeException("Cliente não encontrado: " + dto.clienteId()));

        // --- Usuário é opcional (pode ser null se não informado) ---
        Usuario usuario = null;
        if (dto.usuarioId() != null) {
            // orElse(null) porque o usuário é opcional — não lança exceção se não encontrado
            usuario = usuarioRepository.findById(dto.usuarioId()).orElse(null);
        }

        // --- RF15: valida intervalo de datas ---
        // ChronoUnit.DAYS.between calcula a diferença em dias (sem horário)
        long dias = ChronoUnit.DAYS.between(dto.dataInicio(), dto.dataFim());
        if (dias <= 0) {
            throw new RuntimeException("A data fim deve ser posterior à data de início.");
        }

        // --- RF13: calcula valor total ---
        // BigDecimal.valueOf(dias) para operar com precisão monetária
        BigDecimal valorTotal = carro.getValorDiaria().multiply(BigDecimal.valueOf(dias));

        // Constrói a entidade com todos os dados calculados e validados
        Aluguel aluguel = Aluguel.builder()
                .dataInicio(dto.dataInicio())
                .dataFim(dto.dataFim())
                .valorTotal(valorTotal)
                .status(StatusAluguel.ATIVO) // Todo aluguel nasce com status ATIVO
                .cliente(cliente)
                .carro(carro)
                .usuario(usuario)
                .build();

        // --- RF16: bloqueia o carro para impedir aluguéis simultâneos ---
        carro.setDisponivel(false);
        carroRepository.save(carro); // Salva a mudança de disponibilidade no banco

        return toDTO(aluguelRepository.save(aluguel));
    }

    /**
     * Conclui um aluguel ativo, finalizando normalmente o contrato (RF17).
     * Libera o carro para que possa ser alugado novamente.
     */
    public AluguelDTO concluir(Long id) {
        Aluguel aluguel = aluguelRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Aluguel não encontrado: " + id));

        // Transição de estado: ATIVO → CONCLUIDO
        aluguel.setStatus(StatusAluguel.CONCLUIDO);

        // Libera o carro para novos aluguéis
        aluguel.getCarro().setDisponivel(true);
        carroRepository.save(aluguel.getCarro());

        return toDTO(aluguelRepository.save(aluguel));
    }

    /**
     * Cancela um aluguel ativo antes do término previsto (RF18).
     * Libera o carro para que possa ser alugado novamente.
     */
    public AluguelDTO cancelar(Long id) {
        Aluguel aluguel = aluguelRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Aluguel não encontrado: " + id));

        // Transição de estado: ATIVO → CANCELADO
        aluguel.setStatus(StatusAluguel.CANCELADO);

        // Libera o carro para novos aluguéis
        aluguel.getCarro().setDisponivel(true);
        carroRepository.save(aluguel.getCarro());

        return toDTO(aluguelRepository.save(aluguel));
    }

    // -----------------------------------------------------------------------
    // Método privado de conversão
    // -----------------------------------------------------------------------

    /**
     * Converte entidade Aluguel em AluguelDTO para resposta da API.
     * As entidades relacionadas (Cliente, Carro, Usuario) são representadas
     * apenas por seus IDs — evita serializar objetos aninhados desnecessariamente.
     */
    private AluguelDTO toDTO(Aluguel a) {
        return new AluguelDTO(
                a.getId(),
                a.getDataInicio(),
                a.getDataFim(),
                a.getValorTotal(),
                a.getStatus(),
                a.getCliente().getId(),
                a.getCarro().getId(),
                // usuarioId pode ser null se nenhum atendente foi vinculado ao aluguel
                a.getUsuario() != null ? a.getUsuario().getId() : null
        );
    }
}

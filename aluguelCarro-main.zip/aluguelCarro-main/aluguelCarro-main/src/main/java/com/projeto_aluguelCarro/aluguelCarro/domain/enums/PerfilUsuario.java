package com.projeto_aluguelCarro.aluguelCarro.domain.enums;

/**
 * Enum que define os níveis de acesso (perfis) de um usuário no sistema.
 *
 * É armazenado no banco como texto (String) graças ao @Enumerated(EnumType.STRING)
 * na entidade Usuario. Isso facilita leitura direta no banco e evita problemas
 * com a ordem dos valores caso novos perfis sejam adicionados no futuro.
 */
public enum PerfilUsuario {

    /** Acesso total: pode gerenciar usuários, carros, clientes e aluguéis. */
    ADMIN,

    /** Acesso operacional do dia a dia: registra aluguéis, consulta frota e clientes. */
    ATENDENTE
}

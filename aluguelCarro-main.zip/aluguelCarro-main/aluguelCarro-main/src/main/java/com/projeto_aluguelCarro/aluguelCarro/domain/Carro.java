package com.projeto_aluguelCarro.aluguelCarro.domain;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entidade JPA que representa um veículo da frota da locadora.
 *
 * Anotações Lombok usadas:
 *   @Data           → gera getters, setters, equals, hashCode e toString automaticamente
 *   @NoArgsConstructor → construtor sem argumentos (exigido pelo JPA)
 *   @AllArgsConstructor → construtor com todos os campos (usado internamente)
 *   @Builder        → permite construir objetos de forma fluente:
 *                     Carro.builder().marca("Toyota").modelo("Corolla").build()
 *
 * Mapeamento no banco: tabela "carros"
 */
@Entity
@Table(name = "carros")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Carro {

    /** Chave primária gerada automaticamente pelo banco (AUTO_INCREMENT). */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Fabricante do veículo. Ex: "Toyota", "Honda". Campo obrigatório. */
    @Column(nullable = false)
    private String marca;

    /** Nome do modelo. Ex: "Corolla", "Civic". Campo obrigatório. */
    @Column(nullable = false)
    private String modelo;

    /**
     * Placa do veículo — deve ser única no banco.
     * A unicidade é validada programaticamente no CarroService (RF02)
     * e reforçada pela constraint UNIQUE no banco.
     */
    @Column(unique = true, nullable = false)
    private String placa;

    /** Ano de fabricação. Opcional — pode ser null. */
    private Integer ano;

    /**
     * Preço cobrado por dia de locação.
     * Usado pelo AluguelService para calcular: valorTotal = dias × valorDiaria.
     * BigDecimal garante precisão em cálculos monetários (sem arredondamento de float/double).
     */
    @Column(nullable = false)
    private BigDecimal valorDiaria;

    /**
     * Indica se o carro está disponível para ser alugado.
     * Controlado automaticamente pelo AluguelService:
     *   - false ao criar um aluguel (RF16)
     *   - true ao concluir ou cancelar um aluguel (RF17/RF18)
     *
     * @Builder.Default garante que, ao usar o Builder sem informar este campo,
     * o valor padrão seja true (disponível) em vez de null.
     */
    @Builder.Default
    private Boolean disponivel = true;

    /** Segmento do veículo. Ex: "Sedan", "SUV", "Hatch". Opcional. */
    private String categoria;
}

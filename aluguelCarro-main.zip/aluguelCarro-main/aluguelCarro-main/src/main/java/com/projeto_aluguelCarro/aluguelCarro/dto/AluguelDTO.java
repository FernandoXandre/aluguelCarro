package com.projeto_aluguelCarro.aluguelCarro.dto;

import com.projeto_aluguelCarro.aluguelCarro.domain.enums.StatusAluguel;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * DTO imutável (Java Record) para tráfego de dados de Aluguel.
 *
 * Na CRIAÇÃO (POST /alugueis), o cliente deve enviar:
 *   - dataInicio, dataFim, clienteId, carroId (obrigatórios)
 *   - usuarioId (opcional — pode ser null)
 *   - valorTotal e status são IGNORADOS e calculados/definidos pelo AluguelService:
 *       valorTotal = ChronoUnit.DAYS.between(dataInicio, dataFim) × carro.valorDiaria
 *       status     = ATIVO (automático)
 *
 * Na SAÍDA (GET), todos os campos são preenchidos, incluindo valorTotal e status.
 *
 * Referências às entidades relacionadas são feitas por ID (Long) e não pelo objeto
 * completo, evitando serialização de dados desnecessários e dependências circulares.
 */
public record AluguelDTO(
        Long id,               // Null no cadastro; preenchido pelo banco após salvar
        LocalDate dataInicio,
        LocalDate dataFim,
        BigDecimal valorTotal, // Calculado automaticamente — ignorado no POST
        StatusAluguel status,  // Definido automaticamente — ignorado no POST
        Long clienteId,        // ID do cliente que está alugando
        Long carroId,          // ID do carro a ser alugado
        Long usuarioId         // ID do atendente responsável (pode ser null)
) {}

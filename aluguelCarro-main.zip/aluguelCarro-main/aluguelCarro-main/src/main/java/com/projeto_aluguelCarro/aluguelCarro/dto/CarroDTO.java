package com.projeto_aluguelCarro.aluguelCarro.dto;

import java.math.BigDecimal;

/**
 * DTO (Data Transfer Object) para tráfego de dados de Carro entre o cliente HTTP e a API.
 *
 * Implementado como Java Record (Java 16+): imutável, compacto, sem boilerplate.
 * O compilador gera automaticamente construtor, getters (sem prefixo "get"),
 * equals, hashCode e toString.
 *
 * Usado em ENTRADA (POST/PUT) e SAÍDA (GET):
 *   - POST /carros  → cliente envia CarroDTO sem id (será gerado pelo banco)
 *   - PUT  /carros/{id} → cliente envia dados atualizados (placa é ignorada no Service)
 *   - GET  /carros  → API retorna lista de CarroDTO
 *
 * Por que DTO e não a entidade diretamente?
 *   - Isola o contrato da API do modelo interno do banco
 *   - Evita expor campos ou relacionamentos desnecessários
 *   - Facilita mudanças na entidade sem quebrar a API
 */
public record CarroDTO(
        Long id,           // Null no cadastro; preenchido pelo banco após salvar
        String marca,
        String modelo,
        String placa,
        Integer ano,
        BigDecimal valorDiaria,
        Boolean disponivel, // Controlado internamente; pode ser enviado em atualizações
        String categoria
) {}

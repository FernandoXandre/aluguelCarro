package com.projeto_aluguelCarro.aluguelCarro.domain;

import com.projeto_aluguelCarro.aluguelCarro.domain.enums.StatusAluguel;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Entidade JPA que representa o contrato de locação de um veículo.
 *
 * Um aluguel vincula três entidades: Cliente, Carro e (opcionalmente) Usuario.
 * O relacionamento é feito via chaves estrangeiras (@JoinColumn) e @ManyToOne,
 * pois muitos aluguéis podem pertencer ao mesmo cliente, carro ou usuário.
 *
 * Anotações Lombok:
 *   @Data           → getters, setters, equals, hashCode e toString
 *   @NoArgsConstructor → construtor sem argumentos (obrigatório para JPA)
 *   @AllArgsConstructor → construtor completo
 *   @Builder        → construção fluente: Aluguel.builder().cliente(c).carro(v).build()
 *
 * Mapeamento no banco: tabela "alugueis"
 */
@Entity
@Table(name = "alugueis")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Aluguel {

    /** Chave primária gerada automaticamente pelo banco (AUTO_INCREMENT). */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Data em que o aluguel começa. Obrigatória. Usada para filtro por período. */
    @Column(nullable = false)
    private LocalDate dataInicio;

    /** Data prevista de devolução. Deve ser posterior à dataInicio (validado no AluguelService). */
    @Column(nullable = false)
    private LocalDate dataFim;

    /**
     * Valor total do aluguel em reais.
     * Calculado automaticamente no AluguelService: valorTotal = dias × carro.valorDiaria
     * Não deve ser enviado pelo cliente na criação — será ignorado e recalculado (RF13).
     */
    private BigDecimal valorTotal;

    /**
     * Estado atual do aluguel no seu ciclo de vida (RF12-RF18).
     * EnumType.STRING armazena o nome textual para facilitar leitura no banco.
     * Ver enum StatusAluguel para as transições possíveis.
     */
    @Enumerated(EnumType.STRING)
    private StatusAluguel status;

    /**
     * Cliente que está alugando o veículo.
     * @ManyToOne: muitos aluguéis para um cliente.
     * @JoinColumn: coluna "cliente_id" na tabela alugueis.
     * nullable = false: todo aluguel precisa de um cliente.
     */
    @ManyToOne
    @JoinColumn(name = "cliente_id", nullable = false)
    private Cliente cliente;

    /**
     * Veículo sendo alugado.
     * @ManyToOne: muitos aluguéis para um carro (em períodos diferentes).
     * @JoinColumn: coluna "carro_id" na tabela alugueis.
     * nullable = false: todo aluguel precisa de um carro.
     */
    @ManyToOne
    @JoinColumn(name = "carro_id", nullable = false)
    private Carro carro;

    /**
     * Atendente que registrou o aluguel. Campo opcional (nullable).
     * Se o usuário for deletado, o banco seta usuario_id como NULL
     * (ON DELETE SET NULL definido no script SQL).
     */
    @ManyToOne
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;
}

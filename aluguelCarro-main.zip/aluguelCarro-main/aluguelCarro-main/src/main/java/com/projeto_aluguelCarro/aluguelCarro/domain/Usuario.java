package com.projeto_aluguelCarro.aluguelCarro.domain;

import com.projeto_aluguelCarro.aluguelCarro.domain.enums.PerfilUsuario;
import jakarta.persistence.*;
import lombok.*;

/**
 * Entidade JPA que representa um operador do sistema — atendente ou administrador.
 *
 * Usuários são vinculados aos aluguéis (campo usuarioId no AluguelDTO) para
 * registrar qual atendente registrou cada locação.
 *
 * Anotações Lombok:
 *   @Data           → getters, setters, equals, hashCode e toString
 *   @NoArgsConstructor → construtor sem argumentos (obrigatório para JPA)
 *   @AllArgsConstructor → construtor completo
 *   @Builder        → construção fluente: Usuario.builder().username("admin").build()
 *
 * Mapeamento no banco: tabela "usuarios"
 */
@Entity
@Table(name = "usuarios")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Usuario {

    /** Chave primária gerada automaticamente pelo banco (AUTO_INCREMENT). */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Nome de login do usuário — deve ser único no banco.
     * Validado no UsuarioService (RF21) e reforçado pela constraint UNIQUE.
     */
    @Column(unique = true, nullable = false)
    private String username;

    /**
     * Senha do usuário armazenada em texto puro nesta versão.
     * IMPORTANTE: a senha NUNCA é retornada nas respostas da API (RF22).
     * Isso é garantido pelo UsuarioDTO, que não inclui o campo senha.
     *
     * Melhoria prevista (RNF05): aplicar hash com BCrypt via Spring Security.
     */
    @Column(nullable = false)
    private String senha;

    /**
     * Nível de acesso do usuário.
     * EnumType.STRING armazena o nome textual ("ADMIN" ou "ATENDENTE")
     * em vez do índice numérico, tornando o banco mais legível e seguro
     * contra reordenações futuras do enum.
     */
    @Enumerated(EnumType.STRING)
    private PerfilUsuario perfil;
}

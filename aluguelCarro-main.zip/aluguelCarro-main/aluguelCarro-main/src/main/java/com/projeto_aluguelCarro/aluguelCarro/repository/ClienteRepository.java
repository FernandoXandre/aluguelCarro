package com.projeto_aluguelCarro.aluguelCarro.repository;

import com.projeto_aluguelCarro.aluguelCarro.domain.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

/**
 * Repositório JPA para a entidade Cliente.
 *
 * Herda operações CRUD completas de JpaRepository<Cliente, Long>.
 * Os métodos abaixo são derived queries geradas automaticamente pelo Spring Data.
 *
 * Padrão de Projeto: Repository (DAO) — abstrai o acesso ao banco.
 */
public interface ClienteRepository extends JpaRepository<Cliente, Long> {

    /**
     * Busca um cliente pelo CPF.
     * SQL gerado: SELECT * FROM clientes WHERE cpf = ?
     * Retorna Optional para forçar tratamento do caso "não encontrado".
     */
    Optional<Cliente> findByCpf(String cpf);

    /**
     * Verifica se já existe um cliente com o CPF informado.
     * SQL gerado: SELECT COUNT(*) > 0 FROM clientes WHERE cpf = ?
     * Usado no ClienteService para impedir CPF duplicado (RF08).
     */
    boolean existsByCpf(String cpf);
}

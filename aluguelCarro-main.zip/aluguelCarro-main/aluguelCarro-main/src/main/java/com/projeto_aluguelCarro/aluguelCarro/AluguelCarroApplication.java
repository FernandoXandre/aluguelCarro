package com.projeto_aluguelCarro.aluguelCarro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Classe principal da aplicação — ponto de entrada do Spring Boot.
 *
 * A anotação @SpringBootApplication ativa três comportamentos ao mesmo tempo:
 *   - @Configuration     → indica que esta classe pode declarar beans Spring
 *   - @EnableAutoConfiguration → configura automaticamente o Spring com base nas
 *                                dependências presentes no classpath (ex: JPA, Web)
 *   - @ComponentScan     → varre todos os pacotes abaixo deste buscando
 *                          @Controller, @Service, @Repository, etc.
 *
 * Ao executar, o Spring Boot sobe um servidor Tomcat embutido na porta 8080
 * (configurável em application.properties) e a API já fica disponível.
 */
@SpringBootApplication
public class AluguelCarroApplication {

    public static void main(String[] args) {
        // Inicializa o contexto Spring e sobe o servidor
        SpringApplication.run(AluguelCarroApplication.class, args);
    }
}

package com.projeto_aluguelCarro.aluguelCarro.domain;

import jakarta.persistence.*;
import lombok.*;

/**
 * Entidade JPA que representa o cliente (locatário) da locadora.
 *
 * Anotações Lombok:
 *   @Data           → getters, setters, equals, hashCode e toString
 *   @NoArgsConstructor → construtor sem argumentos (obrigatório para JPA)
 *   @AllArgsConstructor → construtor completo
 *   @Builder        → construção fluente: Cliente.builder().nome("João").build()
 *
 * Mapeamento no banco: tabela "clientes"
 */
@Entity
@Table(name = "clientes")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Cliente {

    /** Chave primária gerada automaticamente pelo banco (AUTO_INCREMENT). */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Nome completo do cliente. Campo obrigatório. */
    @Column(nullable = false)
    private String nome;

    /**
     * CPF do cliente — deve ser único no banco.
     * A unicidade é validada no ClienteService (RF08) e reforçada pela constraint UNIQUE.
     * Não é permitido atualizar o CPF via PUT (RF10) para preservar vínculos com aluguéis.
     */
    @Column(unique = true, nullable = false)
    private String cpf;

    /** E-mail de contato. Opcional. */
    private String email;

    /** Telefone de contato. Opcional. */
    private String telefone;

    /** Endereço residencial completo. Opcional. */
    private String endereco;

    /**
     * Número da Carteira Nacional de Habilitação.
     * Necessário para formalização do contrato de locação. Opcional no cadastro.
     */
    private String cnh;
}

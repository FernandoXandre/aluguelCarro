package com.projeto_aluguelCarro.aluguelCarro.dto;

import com.projeto_aluguelCarro.aluguelCarro.domain.enums.PerfilUsuario;

/**
 * DTO imutável (Java Record) para tráfego de dados de Usuario.
 *
 * IMPORTANTE — Segurança (RF22 / RNF05):
 *   A senha NÃO está presente neste record. Isso garante que ela nunca
 *   apareça nas respostas JSON da API, independente do método chamado.
 *
 *   No POST /usuarios o UsuarioController recebe um Map<String, String>
 *   contendo também a senha, constrói este DTO sem ela e a passa
 *   separadamente para o UsuarioService.
 */
public record UsuarioDTO(
        Long id,              // Null no cadastro; preenchido pelo banco após salvar
        String username,      // Único no sistema
        PerfilUsuario perfil  // ADMIN ou ATENDENTE
        // senha omitida intencionalmente — nunca deve ser retornada pela API
) {}

package com.projeto_aluguelCarro.aluguelCarro.repository;

import com.projeto_aluguelCarro.aluguelCarro.domain.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

/**
 * Repositório JPA para a entidade Usuario.
 *
 * Herda operações CRUD completas de JpaRepository<Usuario, Long>.
 * Os métodos abaixo são derived queries geradas automaticamente pelo Spring Data.
 *
 * Padrão de Projeto: Repository (DAO) — abstrai o acesso ao banco.
 */
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    /**
     * Busca um usuário pelo username (nome de login).
     * SQL gerado: SELECT * FROM usuarios WHERE username = ?
     * Retorna Optional para forçar tratamento do caso "não encontrado".
     */
    Optional<Usuario> findByUsername(String username);

    /**
     * Verifica se já existe um usuário com o username informado.
     * SQL gerado: SELECT COUNT(*) > 0 FROM usuarios WHERE username = ?
     * Usado no UsuarioService para impedir username duplicado (RF21).
     */
    boolean existsByUsername(String username);
}

package com.projeto_aluguelCarro.aluguelCarro.controller;

import com.projeto_aluguelCarro.aluguelCarro.dto.AluguelDTO;
import com.projeto_aluguelCarro.aluguelCarro.service.AluguelService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;

/**
 * Controller REST para criação e controle do ciclo de vida dos aluguéis.
 *
 * Usa tanto @GetMapping/@PostMapping (CRUD) quanto @PatchMapping (operações
 * parciais: concluir e cancelar), seguindo as boas práticas REST (RNF07).
 *
 * Endpoints expostos:
 *   GET   /alugueis                     → listar todos
 *   GET   /alugueis/{id}                → buscar por ID
 *   GET   /alugueis/cliente/{clienteId} → listar por cliente
 *   GET   /alugueis/periodo?inicio=&fim= → listar por período
 *   POST  /alugueis                     → criar (calcula valor e bloqueia carro)
 *   PATCH /alugueis/{id}/concluir       → concluir e liberar carro
 *   PATCH /alugueis/{id}/cancelar       → cancelar e liberar carro
 */
@RestController
@RequestMapping("/alugueis")
public class AluguelController {

    private final AluguelService aluguelService;

    // Injeção via construtor
    public AluguelController(AluguelService aluguelService) {
        this.aluguelService = aluguelService;
    }

    /**
     * GET /alugueis
     * Retorna todos os aluguéis cadastrados.
     */
    @GetMapping
    public List<AluguelDTO> listarTodos() {
        return aluguelService.listarTodos();
    }

    /**
     * GET /alugueis/{id}
     * Busca um aluguel específico pelo ID.
     */
    @GetMapping("/{id}")
    public AluguelDTO buscarPorId(@PathVariable Long id) {
        return aluguelService.buscarPorId(id);
    }

    /**
     * GET /alugueis/cliente/{clienteId}
     * Lista todos os aluguéis de um determinado cliente (RF19).
     */
    @GetMapping("/cliente/{clienteId}")
    public List<AluguelDTO> listarPorCliente(@PathVariable Long clienteId) {
        return aluguelService.listarPorCliente(clienteId);
    }

    /**
     * GET /alugueis/periodo?inicio=2026-01-01&fim=2026-12-31
     * Lista aluguéis cuja dataInicio está dentro do intervalo informado (RF19).
     *
     * @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) instrui o Spring a converter
     * a String do query parameter ("2026-01-01") para LocalDate automaticamente.
     */
    @GetMapping("/periodo")
    public List<AluguelDTO> listarPorPeriodo(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate inicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fim) {
        return aluguelService.listarPorPeriodo(inicio, fim);
    }

    /**
     * POST /alugueis
     * Cria um novo aluguel aplicando todas as regras de negócio (RF12 a RF16):
     *   - verifica disponibilidade do carro
     *   - valida datas
     *   - calcula o valorTotal automaticamente
     *   - marca o carro como indisponível
     *
     * Body JSON esperado:
     * {
     *   "dataInicio": "2026-06-01",
     *   "dataFim":    "2026-06-05",
     *   "clienteId":  1,
     *   "carroId":    1,
     *   "usuarioId":  1   (opcional)
     * }
     */
    @PostMapping
    public AluguelDTO criar(@RequestBody AluguelDTO dto) {
        return aluguelService.criar(dto);
    }

    /**
     * PATCH /alugueis/{id}/concluir
     * Finaliza normalmente um aluguel ativo (RF17).
     * Muda status para CONCLUIDO e libera o carro (disponivel = true).
     * PATCH é usado em vez de PUT porque altera apenas o estado, não todos os campos.
     */
    @PatchMapping("/{id}/concluir")
    public AluguelDTO concluir(@PathVariable Long id) {
        return aluguelService.concluir(id);
    }

    /**
     * PATCH /alugueis/{id}/cancelar
     * Cancela um aluguel ativo antes do prazo (RF18).
     * Muda status para CANCELADO e libera o carro (disponivel = true).
     */
    @PatchMapping("/{id}/cancelar")
    public AluguelDTO cancelar(@PathVariable Long id) {
        return aluguelService.cancelar(id);
    }
}

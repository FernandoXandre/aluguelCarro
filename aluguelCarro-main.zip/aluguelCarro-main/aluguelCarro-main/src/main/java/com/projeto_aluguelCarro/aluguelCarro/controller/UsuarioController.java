package com.projeto_aluguelCarro.aluguelCarro.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.projeto_aluguelCarro.aluguelCarro.domain.enums.PerfilUsuario;
import com.projeto_aluguelCarro.aluguelCarro.dto.UsuarioDTO;
import com.projeto_aluguelCarro.aluguelCarro.service.UsuarioService;

/**
 * Controller REST para gerenciamento dos usuários operacionais do sistema
 * (atendentes e administradores).
 *
 * Design especial no POST — por que Map<String, String> e não UsuarioDTO?
 *
 *   O UsuarioDTO foi projetado SEM o campo senha para que ela nunca apareça
 *   nas respostas JSON (RF22). Se usássemos um DTO de entrada diferente com senha,
 *   precisaríamos de dois DTOs. A solução adotada foi receber um Map genérico,
 *   extrair a senha manualmente e construir o UsuarioDTO sem ela.
 *
 *   Requisição POST esperada:
 *   {
 *     "username": "atendente01",
 *     "senha":    "minhasenha",
 *     "perfil":   "ATENDENTE"
 *   }
 *
 * Endpoints expostos:
 *   GET    /usuarios       → listar todos (senha nunca retornada)
 *   GET    /usuarios/{id}  → buscar por ID
 *   POST   /usuarios       → cadastrar (body: Map com username, senha, perfil)
 *   DELETE /usuarios/{id}  → remover
 */
@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    private final UsuarioService usuarioService;

    // Injeção via construtor
    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    /**
     * GET /usuarios
     * Lista todos os usuários. A senha é omitida automaticamente pelo UsuarioDTO (RF22).
     */
    @GetMapping
    public List<UsuarioDTO> listarTodos() {
        return usuarioService.listarTodos();
    }

    /**
     * GET /usuarios/{id}
     * Busca um usuário pelo ID. A senha nunca é retornada.
     */
    @GetMapping("/{id}")
    public UsuarioDTO buscarPorId(@PathVariable Long id) {
        return usuarioService.buscarPorId(id);
    }

    /**
     * POST /usuarios
     * Cadastra um novo usuário (RF20).
     *
     * Recebe Map<String, String> para extrair a senha do body sem incluí-la no
     * UsuarioDTO de resposta. Assim a senha trafega na entrada mas nunca na saída.
     *
     * PerfilUsuario.valueOf() converte a String "ADMIN" ou "ATENDENTE" para o enum.
     * Lança IllegalArgumentException se o valor for inválido.
     */
    @PostMapping
    public UsuarioDTO salvar(@RequestBody Map<String, String> body) {
        // Monta o DTO sem a senha (ela não deve aparecer no retorno)
        UsuarioDTO dto = new UsuarioDTO(
                null,                                       // id será gerado pelo banco
                body.get("username"),
                PerfilUsuario.valueOf(body.get("perfil"))   // converte String → enum
        );
        // Passa a senha separadamente para o Service
        return usuarioService.salvar(dto, body.get("senha"));
    }

    /**
     * DELETE /usuarios/{id}
     * Remove um usuário. Os aluguéis vinculados terão usuario_id = NULL
     * (ON DELETE SET NULL no banco — preserva o histórico de locações).
     * Retorna HTTP 204 No Content.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        usuarioService.deletar(id);
        return ResponseEntity.noContent().build(); // HTTP 204 No Content
    }
}

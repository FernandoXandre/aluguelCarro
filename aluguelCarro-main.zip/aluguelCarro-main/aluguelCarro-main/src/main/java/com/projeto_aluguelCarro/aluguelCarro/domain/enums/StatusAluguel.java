package com.projeto_aluguelCarro.aluguelCarro.domain.enums;

/**
 * Enum que representa o ciclo de vida de um aluguel.
 *
 * Transições válidas (definidas no AluguelService):
 *
 *   Carro disponível
 *       │
 *       ▼  POST /alugueis
 *     ATIVO  ──── carro.disponivel = false
 *       │
 *       ├──► PATCH /concluir ──► CONCLUIDO  (carro.disponivel = true)
 *       │
 *       └──► PATCH /cancelar ──► CANCELADO  (carro.disponivel = true)
 *
 * PENDENTE existe no modelo de dados mas não é usado na lógica atual;
 * pode ser aproveitado futuramente para reservas antecipadas.
 */
public enum StatusAluguel {

    /** Reservado, mas ainda não iniciado (uso futuro). */
    PENDENTE,

    /** Em andamento — carro marcado como indisponível no banco. */
    ATIVO,

    /** Finalizado normalmente — carro liberado para novos aluguéis. */
    CONCLUIDO,

    /** Interrompido antes do prazo — carro liberado para novos aluguéis. */
    CANCELADO
}

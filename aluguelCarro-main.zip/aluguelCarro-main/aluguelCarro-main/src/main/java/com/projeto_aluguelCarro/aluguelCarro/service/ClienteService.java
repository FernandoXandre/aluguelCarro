package com.projeto_aluguelCarro.aluguelCarro.service;

import com.projeto_aluguelCarro.aluguelCarro.domain.Cliente;
import com.projeto_aluguelCarro.aluguelCarro.dto.ClienteDTO;
import com.projeto_aluguelCarro.aluguelCarro.repository.AluguelRepository;
import com.projeto_aluguelCarro.aluguelCarro.repository.ClienteRepository;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Serviço responsável pela lógica de negócio dos clientes da locadora.
 *
 * Recebe dois repositórios via injeção de construtor:
 *   - ClienteRepository: operações CRUD de clientes
 *   - AluguelRepository: usado para verificar vínculos antes de excluir
 *
 * A injeção de dois repositórios em um Service é normal quando a regra
 * de negócio envolve mais de uma entidade (ex: bloquear exclusão de cliente
 * que possui aluguéis — RF11).
 */
@Service
public class ClienteService {

    private final ClienteRepository clienteRepository;
    private final AluguelRepository aluguelRepository;

    // Injeção via construtor — Spring injeta ambos automaticamente
    public ClienteService(ClienteRepository clienteRepository, AluguelRepository aluguelRepository) {
        this.clienteRepository = clienteRepository;
        this.aluguelRepository = aluguelRepository;
    }

    /**
     * Retorna todos os clientes cadastrados (RF09).
     */
    public List<ClienteDTO> listarTodos() {
        return clienteRepository.findAll().stream()
                .map(this::toDTO)
                .toList();
    }

    /**
     * Busca um cliente pelo ID (RF09).
     * Lança RuntimeException com mensagem clara se não encontrado.
     */
    public ClienteDTO buscarPorId(Long id) {
        return toDTO(clienteRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cliente não encontrado: " + id)));
    }

    /**
     * Cadastra um novo cliente (RF07).
     * Regra RF08: impede CPF duplicado antes de persistir.
     */
    public ClienteDTO salvar(ClienteDTO dto) {
        // Verifica unicidade do CPF antes de salvar
        if (clienteRepository.existsByCpf(dto.cpf())) {
            throw new RuntimeException("CPF já cadastrado: " + dto.cpf());
        }
        return toDTO(clienteRepository.save(toEntity(dto)));
    }

    /**
     * Atualiza os dados de um cliente existente (RF10).
     * Regra RF10: o CPF NÃO é atualizado para preservar o vínculo com
     * aluguéis já registrados — alterar o CPF quebraria a rastreabilidade.
     */
    public ClienteDTO atualizar(Long id, ClienteDTO dto) {
        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cliente não encontrado: " + id));

        // Atualiza apenas os campos permitidos — cpf é preservado intencionalmente
        cliente.setNome(dto.nome());
        cliente.setEmail(dto.email());
        cliente.setTelefone(dto.telefone());
        cliente.setEndereco(dto.endereco());
        cliente.setCnh(dto.cnh());

        return toDTO(clienteRepository.save(cliente));
    }

    /**
     * Remove um cliente pelo ID (RF11).
     * Regra RF11: bloqueia a exclusão se o cliente tiver algum aluguel registrado,
     * pois isso quebraria a integridade referencial do histórico de locações.
     */
    public void deletar(Long id) {
        // Consulta no AluguelRepository se há aluguéis vinculados ao clienteId
        if (aluguelRepository.existsByClienteId(id)) {
            throw new RuntimeException("Cliente possui aluguéis registrados e não pode ser removido.");
        }
        clienteRepository.deleteById(id);
    }

    // -----------------------------------------------------------------------
    // Métodos privados de conversão
    // -----------------------------------------------------------------------

    /** Converte entidade Cliente em ClienteDTO para resposta da API. */
    private ClienteDTO toDTO(Cliente c) {
        return new ClienteDTO(c.getId(), c.getNome(), c.getCpf(),
                c.getEmail(), c.getTelefone(), c.getEndereco(), c.getCnh());
    }

    /** Converte ClienteDTO recebido da requisição em entidade Cliente para persistência. */
    private Cliente toEntity(ClienteDTO dto) {
        return Cliente.builder()
                .id(dto.id())
                .nome(dto.nome())
                .cpf(dto.cpf())
                .email(dto.email())
                .telefone(dto.telefone())
                .endereco(dto.endereco())
                .cnh(dto.cnh())
                .build();
    }
}

package com.projeto_aluguelCarro.aluguelCarro.dto;

/**
 * DTO imutável (Java Record) para tráfego de dados de Cliente.
 *
 * Usado em ENTRADA (POST/PUT) e SAÍDA (GET).
 *
 * Observações de negócio:
 *   - No PUT /clientes/{id} o campo cpf é recebido mas IGNORADO no ClienteService (RF10),
 *     pois o CPF não pode ser alterado após o cadastro.
 *   - Todos os campos exceto id, nome e cpf são opcionais (podem ser null).
 */
public record ClienteDTO(
        Long id,       // Null no cadastro; preenchido pelo banco após salvar
        String nome,
        String cpf,    // Único no sistema; não pode ser alterado após cadastro
        String email,
        String telefone,
        String endereco,
        String cnh     // Carteira Nacional de Habilitação
) {}

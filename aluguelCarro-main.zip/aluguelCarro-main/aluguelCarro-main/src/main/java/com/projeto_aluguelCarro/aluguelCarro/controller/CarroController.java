package com.projeto_aluguelCarro.aluguelCarro.controller;

import com.projeto_aluguelCarro.aluguelCarro.dto.CarroDTO;
import com.projeto_aluguelCarro.aluguelCarro.service.CarroService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * Controller REST para operações de gerenciamento da frota de veículos.
 *
 * Responsabilidades desta camada (APENAS):
 *   - Receber requisições HTTP
 *   - Extrair dados do body/path/query
 *   - Delegar processamento ao CarroService
 *   - Retornar respostas HTTP com o status correto
 *
 * NÃO contém lógica de negócio — toda a lógica está no CarroService.
 *
 * Anotações Spring:
 *   @RestController   → combina @Controller + @ResponseBody:
 *                       os métodos retornam objetos que são serializados para JSON
 *   @RequestMapping   → define a URL base de todos os endpoints desta classe
 *
 * Endpoints expostos:
 *   GET    /carros            → listar todos
 *   GET    /carros/disponiveis → listar disponíveis
 *   GET    /carros/{id}       → buscar por ID
 *   POST   /carros            → cadastrar
 *   PUT    /carros/{id}       → atualizar
 *   DELETE /carros/{id}       → remover
 */
@RestController
@RequestMapping("/carros")
public class CarroController {

    private final CarroService carroService;

    // Injeção via construtor — Spring injeta o CarroService automaticamente
    public CarroController(CarroService carroService) {
        this.carroService = carroService;
    }

    /**
     * GET /carros
     * Lista todos os carros da frota, disponíveis ou não.
     * Retorna HTTP 200 com lista JSON.
     */
    @GetMapping
    public List<CarroDTO> listarTodos() {
        return carroService.listarTodos();
    }

    /**
     * GET /carros/disponiveis
     * Lista apenas carros com disponivel = true (aptos para locação).
     * ATENÇÃO: este endpoint deve ser declarado ANTES de /{id} para que
     * a palavra "disponiveis" não seja interpretada como um ID numérico.
     */
    @GetMapping("/disponiveis")
    public List<CarroDTO> listarDisponiveis() {
        return carroService.listarDisponiveis();
    }

    /**
     * GET /carros/{id}
     * Busca um carro específico pelo ID.
     * @PathVariable extrai o valor {id} da URL e o passa como parâmetro Long.
     */
    @GetMapping("/{id}")
    public CarroDTO buscarPorId(@PathVariable Long id) {
        return carroService.buscarPorId(id);
    }

    /**
     * POST /carros
     * Cadastra um novo veículo na frota.
     * @RequestBody desserializa o JSON do corpo da requisição para CarroDTO.
     * Retorna o CarroDTO salvo (com o id gerado pelo banco).
     */
    @PostMapping
    public CarroDTO salvar(@RequestBody CarroDTO dto) {
        return carroService.salvar(dto);
    }

    /**
     * PUT /carros/{id}
     * Atualiza os dados de um carro existente (exceto a placa — regra do Service).
     * Retorna o CarroDTO atualizado.
     */
    @PutMapping("/{id}")
    public CarroDTO atualizar(@PathVariable Long id, @RequestBody CarroDTO dto) {
        return carroService.atualizar(id, dto);
    }

    /**
     * DELETE /carros/{id}
     * Remove um veículo da frota.
     * ResponseEntity<Void> permite controlar o status HTTP manualmente.
     * noContent().build() retorna HTTP 204 (No Content) — padrão REST para DELETE.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        carroService.deletar(id);
        return ResponseEntity.noContent().build(); // HTTP 204 No Content
    }
}
